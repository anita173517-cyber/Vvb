package com.harindra.iptvpro

import okhttp3.ConnectionPool
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Dispatcher
import okhttp3.Dns
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Protocol
import java.net.InetAddress
import java.net.URLDecoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * RAM PLAYER v21.0 EXTREME MASTER EDITION — Scoped Network & Header Engine:
 *
 * CRITICAL v21.0 HEADER SCOPING FIX:
 * - Eliminates the v20.0 host-wide header leak (`hostStreamHeaders[host]`) where Channel A's
 *   custom headers accidentally leaked onto Channel B on the same provider host.
 * - Implements 4-tier scoped header resolution:
 *   1. Exact stream URL match (`customStreamHeaders[url]`)
 *   2. Exact URL without query token (`baseNoQueryHeaders[baseNoQuery]`)
 *   3. Scoped channel directory path-prefix match (`pathPrefixHeaders[origin + dirPath]`) for HLS
 *      variant playlists, init segments, and `.ts`/`.m4s` media segments belonging to that channel
 *      (never matches bare root `/` so unrelated channels on the same host stay isolated)
 *   4. Explicit redirect-chain mapping (`redirectStreamHeaders[targetUrl]`) with cross-host
 *      credential protection (never leaks `Authorization` or `Cookie` to unrelated hosts).
 */
object NetworkClient {
    const val DEFAULT_USER_AGENT = "RAMPlayer/21.0-AMOLED (AndroidTV)"
    private const val DNS_TTL_MS = 30L * 60L * 1000L // 30-minute TTL
    private const val MAX_DNS_ENTRIES = 64
    private const val MAX_HEADER_ENTRIES = 512
    private const val MAX_REDIRECT_ENTRIES = 256
    private const val MAX_COOKIE_HOSTS = 64

    private data class DnsEntry(
        val addresses: List<InetAddress>,
        val timestampMs: Long
    )

    private val dnsCache = ConcurrentHashMap<String, DnsEntry>(64)
    private val customStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val baseNoQueryHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val pathPrefixHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val redirectStreamHeaders = ConcurrentHashMap<String, Map<String, String>>(64)
    private val sessionCookiesByHost = ConcurrentHashMap<String, List<Cookie>>(32)

    private val ALLOWED_CUSTOM_HEADERS = setOf(
        "user-agent",
        "referer",
        "origin",
        "authorization",
        "cookie",
        "x-forwarded-for",
        "x-requested-with",
        "accept",
        "accept-language"
    )

    private val SENSITIVE_CROSS_HOST_HEADERS = setOf(
        "authorization",
        "cookie"
    )

    private val SENSITIVE_QUERY_REGEX = Regex(
        "(?i)(password|pass|token|auth|key|api_key|access_token|wmsAuthSign|signature)=([^&\\s]+)"
    )
    private val SENSITIVE_PATH_REGEX = Regex(
        "(?i)(/(?:live|movie|series)/[^/]+/)([^/]+)(/)"
    )

    /**
     * Bounded thread-safe in-memory DNS cache (max 64 hosts, 30-min TTL)
     * so channel switches on the same or previously visited IPTV host require 0ms DNS lookup.
     */
    val quantumDns: Dns = object : Dns {
        override fun lookup(hostname: String): List<InetAddress> {
            val key = hostname.lowercase(Locale.ROOT)
            val now = System.currentTimeMillis()
            val cached = dnsCache[key]
            if (cached != null && (now - cached.timestampMs) < DNS_TTL_MS && cached.addresses.isNotEmpty()) {
                return cached.addresses
            }
            val resolved = Dns.SYSTEM.lookup(hostname)
            if (resolved.isNotEmpty()) {
                if (dnsCache.size >= MAX_DNS_ENTRIES) {
                    val oldestKey = dnsCache.entries.minByOrNull { it.value.timestampMs }?.key
                    if (oldestKey != null) dnsCache.remove(oldestKey)
                }
                dnsCache[key] = DnsEntry(resolved, now)
            }
            return resolved
        }
    }

    /**
     * Lightweight in-memory CookieJar scoped strictly per-host so IPTV session cookies set on
     * manifest redirects are preserved between StreamPreFetcher and ExoPlayer's OkHttpDataSource
     * without leaking cookies across unrelated hosts.
     */
    val sessionCookieJar: CookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            if (cookies.isEmpty()) return
            val host = url.host.lowercase(Locale.ROOT)
            if (sessionCookiesByHost.size >= MAX_COOKIE_HOSTS && !sessionCookiesByHost.containsKey(host)) {
                val firstKey = sessionCookiesByHost.keys.firstOrNull()
                if (firstKey != null) sessionCookiesByHost.remove(firstKey)
            }
            val now = System.currentTimeMillis()
            val existing = sessionCookiesByHost[host].orEmpty().filter { it.expiresAt > now }
            val merged = HashMap<String, Cookie>(existing.size + cookies.size)
            for (c in existing) merged[c.name] = c
            for (c in cookies) merged[c.name] = c
            sessionCookiesByHost[host] = merged.values.toList()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val host = url.host.lowercase(Locale.ROOT)
            val list = sessionCookiesByHost[host] ?: return emptyList()
            val now = System.currentTimeMillis()
            return list.filter { it.expiresAt > now && it.matches(url) }
        }
    }

    /**
     * Computes a channel-scoped directory prefix (e.g. `https://cdn.example/live/ch1/`) when the URL
     * has at least 2 path segments or a dedicated leaf directory. Returns null for root-level URLs
     * like `https://cdn.example/ch1.m3u8` so headers NEVER bleed across sibling channels at `/`.
     */
    private fun extractScopedDirectoryPrefix(url: String): String? {
        val parsed = url.toHttpUrlOrNull() ?: return null
        val segments = parsed.pathSegments.filter { it.isNotEmpty() }
        // Require at least 2 segments (e.g. /ch1/index.m3u8 or /live/ch1/master.m3u8)
        // so /ch1.m3u8 and /ch2.m3u8 at root do not collide, and /live/ch1.m3u8 vs /live/ch2.m3u8
        // only share a prefix if they have a deeper channel folder (>=3 segments like /live/ch1/index.m3u8).
        val lastSeg = segments.lastOrNull().orEmpty()
        val hasFileLeaf = lastSeg.contains('.')
        val dirSegments = if (hasFileLeaf) segments.dropLast(1) else segments
        if (dirSegments.isEmpty()) return null
        // Avoid scoping generic shared folders like `/live/` or `/hls/` that host many unrelated channels
        if (dirSegments.size == 1) {
            val single = dirSegments[0].lowercase(Locale.ROOT)
            if (single in setOf("live", "hls", "stream", "streams", "iptv", "tv", "play", "movie", "series")) {
                return null
            }
        }
        val portPart = if ((parsed.scheme == "http" && parsed.port == 80) || (parsed.scheme == "https" && parsed.port == 443)) {
            ""
        } else {
            ":${parsed.port}"
        }
        return "${parsed.scheme}://${parsed.host.lowercase(Locale.ROOT)}$portPart/${dirSegments.joinToString("/")}/"
    }

    private fun canonicalHeaderName(rawKey: String): String {
        return when (rawKey.trim().lowercase(Locale.ROOT)) {
            "user-agent" -> "User-Agent"
            "referer", "referrer" -> "Referer"
            "origin" -> "Origin"
            "authorization" -> "Authorization"
            "cookie" -> "Cookie"
            "x-forwarded-for" -> "X-Forwarded-For"
            "x-requested-with" -> "X-Requested-With"
            "accept" -> "Accept"
            "accept-language" -> "Accept-Language"
            else -> rawKey.trim()
        }
    }

    /**
     * Parses pipe-syntax IPTV URLs (e.g. "https://host/live.m3u8|User-Agent=Custom&Referer=https://...")
     * and optional #EXTVLCOPT/#KODIPROP header maps, registers them with strict channel scoping,
     * and returns the clean stream URL with all signed query parameters preserved verbatim.
     */
    fun extractCleanUrlAndRegisterHeaders(
        rawUrl: String,
        extraHeaders: Map<String, String> = emptyMap()
    ): String {
        val trimmed = rawUrl.trim()
        val pipeIdx = trimmed.indexOf('|')
        val cleanUrl = if (pipeIdx > 0) trimmed.substring(0, pipeIdx).trim() else trimmed
        val merged = LinkedHashMap<String, String>()

        for ((k, v) in extraHeaders) {
            val canonical = canonicalHeaderName(k)
            val cleanVal = v.trim()
            if (canonical.lowercase(Locale.ROOT) in ALLOWED_CUSTOM_HEADERS && cleanVal.isNotEmpty()) {
                merged[canonical] = cleanVal
            }
        }

        if (pipeIdx > 0 && pipeIdx < trimmed.lastIndex) {
            val headerPart = trimmed.substring(pipeIdx + 1)
            for (pair in headerPart.split('&')) {
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    val canonical = canonicalHeaderName(pair.substring(0, eq))
                    val rawVal = runCatching {
                        URLDecoder.decode(pair.substring(eq + 1).trim(), "UTF-8")
                    }.getOrElse { pair.substring(eq + 1).trim() }
                    if (canonical.lowercase(Locale.ROOT) in ALLOWED_CUSTOM_HEADERS && rawVal.isNotEmpty()) {
                        merged[canonical] = rawVal
                    }
                }
            }
        }

        if (merged.isNotEmpty() && cleanUrl.isNotEmpty()) {
            registerStreamHeaders(cleanUrl, merged)
        }
        return cleanUrl
    }

    fun registerStreamHeaders(streamUrl: String, headers: Map<String, String>) {
        if (streamUrl.isBlank() || headers.isEmpty()) return
        val sanitized = LinkedHashMap<String, String>(headers.size)
        for ((k, v) in headers) {
            val canonical = canonicalHeaderName(k)
            val cleanVal = v.trim()
            if (canonical.lowercase(Locale.ROOT) in ALLOWED_CUSTOM_HEADERS && cleanVal.isNotEmpty()) {
                sanitized[canonical] = cleanVal
            }
        }
        if (sanitized.isEmpty()) return

        if (customStreamHeaders.size >= MAX_HEADER_ENTRIES) {
            val firstKey = customStreamHeaders.keys.firstOrNull()
            if (firstKey != null) customStreamHeaders.remove(firstKey)
        }
        customStreamHeaders[streamUrl] = sanitized

        val baseNoQuery = streamUrl.substringBefore('?')
        if (baseNoQuery.isNotBlank()) {
            if (baseNoQueryHeaders.size >= MAX_HEADER_ENTRIES) {
                val firstKey = baseNoQueryHeaders.keys.firstOrNull()
                if (firstKey != null) baseNoQueryHeaders.remove(firstKey)
            }
            baseNoQueryHeaders[baseNoQuery] = sanitized
        }

        val dirPrefix = extractScopedDirectoryPrefix(streamUrl)
        if (!dirPrefix.isNullOrBlank()) {
            if (pathPrefixHeaders.size >= MAX_HEADER_ENTRIES) {
                val firstKey = pathPrefixHeaders.keys.firstOrNull()
                if (firstKey != null) pathPrefixHeaders.remove(firstKey)
            }
            pathPrefixHeaders[dirPrefix] = sanitized
        }
    }

    /**
     * Propagates scoped headers across a redirect or HLS variant/segment URL belonging to `sourceUrl`.
     * Protects credentials: `Authorization` and `Cookie` are ONLY forwarded when redirecting to the
     * SAME host, never across unrelated domains.
     */
    fun registerScopedDerivedUrl(sourceUrl: String, derivedUrl: String) {
        if (sourceUrl.isBlank() || derivedUrl.isBlank() || sourceUrl == derivedUrl) return
        val sourceHeaders = headersForUrl(sourceUrl)
        if (sourceHeaders.isEmpty()) return

        val srcHost = sourceUrl.toHttpUrlOrNull()?.host?.lowercase(Locale.ROOT)
        val dstHost = derivedUrl.toHttpUrlOrNull()?.host?.lowercase(Locale.ROOT)
        val sameHost = !srcHost.isNullOrBlank() && srcHost == dstHost

        val filtered = if (sameHost) {
            sourceHeaders
        } else {
            sourceHeaders.filterKeys { it.lowercase(Locale.ROOT) !in SENSITIVE_CROSS_HOST_HEADERS }
        }
        if (filtered.isEmpty()) return

        if (redirectStreamHeaders.size >= MAX_REDIRECT_ENTRIES) {
            val firstKey = redirectStreamHeaders.keys.firstOrNull()
            if (firstKey != null) redirectStreamHeaders.remove(firstKey)
        }
        redirectStreamHeaders[derivedUrl] = filtered

        val derivedPrefix = extractScopedDirectoryPrefix(derivedUrl)
        if (!derivedPrefix.isNullOrBlank() && !pathPrefixHeaders.containsKey(derivedPrefix)) {
            pathPrefixHeaders[derivedPrefix] = filtered
        }
    }

    fun headersForUrl(url: String): Map<String, String> {
        if (url.isBlank()) return emptyMap()
        // 1. Exact URL match
        customStreamHeaders[url]?.let { return it }
        // 2. Explicit redirect / variant match
        redirectStreamHeaders[url]?.let { return it }
        // 3. Exact base URL without query token
        val baseNoQuery = url.substringBefore('?')
        baseNoQueryHeaders[baseNoQuery]?.let { return it }
        // 4. Scoped channel directory prefix match (longest matching prefix wins, never host-wide)
        var bestPrefixLen = 0
        var bestHeaders: Map<String, String>? = null
        for ((prefix, hdrs) in pathPrefixHeaders) {
            if (baseNoQuery.startsWith(prefix, ignoreCase = true) && prefix.length > bestPrefixLen) {
                bestPrefixLen = prefix.length
                bestHeaders = hdrs
            }
        }
        return bestHeaders ?: emptyMap()
    }

    fun clearStreamHeaders() {
        customStreamHeaders.clear()
        baseNoQueryHeaders.clear()
        pathPrefixHeaders.clear()
        redirectStreamHeaders.clear()
    }

    /**
     * Redacts passwords, tokens, and Xtream /live|movie|series/<user>/<pass>/ path segments so sensitive
     * credentials are never written to Logcat or exposed in UI error strings.
     */
    fun redactSensitiveUrl(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var masked = raw.replace(SENSITIVE_QUERY_REGEX, "$1=****")
        masked = masked.replace(SENSITIVE_PATH_REGEX, "$1****$3")
        return masked
    }

    private val streamHeaderInterceptor = Interceptor { chain ->
        val original = chain.request()
        val urlStr = original.url.toString()
        val custom = headersForUrl(urlStr)
        val builder = original.newBuilder()
        if (original.header("User-Agent").isNullOrBlank()) {
            builder.header("User-Agent", DEFAULT_USER_AGENT)
        }
        for ((k, v) in custom) {
            if (original.header(k).isNullOrBlank() || k.equals("User-Agent", ignoreCase = true)) {
                builder.header(k, v)
            }
        }
        val response = chain.proceed(builder.build())
        val finalUrl = response.request.url.toString()
        if (finalUrl != urlStr && custom.isNotEmpty()) {
            registerScopedDerivedUrl(urlStr, finalUrl)
        }
        response
    }

    fun prewarmHostDns(streamUrl: String?) {
        if (streamUrl.isNullOrBlank()) return
        runCatching {
            val host = streamUrl.toHttpUrlOrNull()?.host ?: return
            quantumDns.lookup(host)
        }
    }

    fun cancelCallsWithTag(tag: Any) {
        runCatching {
            for (client in listOf(fastMetaClient, apiClient)) {
                for (call in client.dispatcher.queuedCalls()) {
                    if (call.request().tag() == tag) call.cancel()
                }
                for (call in client.dispatcher.runningCalls()) {
                    if (call.request().tag() == tag) call.cancel()
                }
            }
        }
    }

    fun evictIdleConnections() {
        runCatching {
            metadataPool.evictAll()
            apiPool.evictAll()
        }
    }

    private fun dispatcher(max: Int, perHost: Int) = Dispatcher().apply {
        maxRequests = max
        maxRequestsPerHost = perHost
    }

    private fun pool(maxIdle: Int) = ConnectionPool(maxIdle, 5, TimeUnit.MINUTES)

    private val metadataDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val apiDispatcher by lazy { dispatcher(max = 5, perHost = 3) }
    private val streamDispatcher by lazy { dispatcher(max = 12, perHost = 6) }

    private val metadataPool by lazy { pool(maxIdle = 4) }
    private val apiPool by lazy { pool(maxIdle = 4) }
    private val streamPool by lazy { pool(maxIdle = 8) }

    /** Short, bounded calls for connection checks, pre-fetch warmup and lightweight metadata. */
    val fastMetaClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(metadataPool)
            .dispatcher(metadataDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .writeTimeout(8, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Longer timeouts for M3U, Xtream and XMLTV responses. */
    val apiClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(apiPool)
            .dispatcher(apiDispatcher)
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    /** Dedicated live-stream dispatcher with 0ms cached DNS, scoped headers, session CookieJar & 5-min keep-alive pool. */
    val streamClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .dns(quantumDns)
            .cookieJar(sessionCookieJar)
            .addInterceptor(streamHeaderInterceptor)
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .connectionPool(streamPool)
            .dispatcher(streamDispatcher)
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }
}
