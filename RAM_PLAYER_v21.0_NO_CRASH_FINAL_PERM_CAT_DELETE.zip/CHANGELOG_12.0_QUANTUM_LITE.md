# StreamX Media3 Pro — v12.0 Quantum-Lite 512MB Ultra-Fast Random Zap Edition

Built on top of **StreamX Media3 Pro 5.2.0 Ultimate**, this upgrade transforms the player into the **v12.0 Quantum-Lite 512MB Ultra-Fast Random Zap Edition** while preserving 100% of the existing 5.2.0 features, package identity (`com.harindra.iptvpro`), and DTH Dark-Glass UI.

## 12 Hyper-Optimized Upgrades Implemented

1. **Ultra-Fast Random Zap Engine (24MB `SimpleCache` + 3-Tier `CacheWriter` Pre-Fetcher + Chunkless HLS)** (`StreamPreFetcher.kt`, `PlayerActivity.kt`):
   - Strictly ONE hardware `ExoPlayer` instance to prevent `MediaCodec` multi-instance crashes on 512MB SoCs.
   - Thread-safe Media3 `SimpleCache` (`LeastRecentlyUsedCacheEvictor(24 * 1024 * 1024)` — strictly 24MB cap in `cacheDir`) attached to `CacheDataSource.Factory`.
   - **Tier 1 (Adjacent `N+1` & `N-1`)**: Pre-warms manifest + up to 512KB after active playback stabilizes.
   - **Tier 2 (D-Pad Focus Pre-Fetch)**: When highlighting any channel in the Channel Sidebar for `>180ms`, pre-warms manifest + up to 256KB before `OK` is pressed.
   - **Tier 3 (Top-8 Favorites/Recents Warmup)**: Round-robin pre-warms manifest + up to 192KB of top 8 Favorite/Recent channels during idle playback.
   - Enabled `.setAllowChunklessPreparation(true)` on `HlsMediaSource.Factory`.
2. **120ms Instant Start Buffer, 64KB `DefaultAllocator` & 18MB Live Heap Guard** (`PlayerActivity.kt`):
   - `DefaultAllocator(true, 64 * 1024)` zero-copy 64KB chunk pool.
   - `LOW_MEMORY_512MB` Quantum-Lite buffer profile: `bufferForPlaybackMs = 120`, `bufferForPlaybackAfterRebufferMs = 600`, `minBufferMs = 10000`, `maxBufferMs = 20000`, `setBackBuffer(0, false)`, `setTargetBufferBytes(5 * 1024 * 1024)` (5MB cap).
   - Live Heap Guard trims idle cache/allocator if free + unallocated JVM heap falls below `18MB`.
3. **Hardware Overlay `SurfaceView` & Zero Black-Flash** (`activity_player.xml`, `PlayerActivity.kt`):
   - `app:surface_type="surface_view"`, `app:keep_content_on_player_reset="true"`, `app:shutter_background_color="#000000"`, and `android:keepScreenOn="true"`.
4. **Smart Adaptive Resolution & Codec Safety Guard** (`PlayerActivity.kt`):
   - `setMaxVideoSize(1920, 1080)` and `setMaxVideoBitrate(8_000_000)` (8 Mbps cap) on 512MB RAM TVs, `setEnableDecoderFallback(true)`, and `setTunnelingEnabled(false)`.
5. **Zero-Jank 60fps UI Thread Lock** (`M3uParser.kt`, `XmltvParser.kt`, `PlayerActivity.kt`):
   - Streaming `BufferedReader` + `JsonReader` + `XmlPullParser` + primitive `IntArray` indexing off the main thread.
6. **GPU-Only 60fps Glass Animations** (`PlayerActivity.kt`, `activity_player.xml`):
   - Hardware layer animations (`withLayer()`) on DTH startup overlay and OSD transitions.
7. **Ultra-Compact `RGB_565` 80x80 Logo Cache & Scroll-Freeze Guard** (`PlayerActivity.kt`):
   - `DecodeFormat.PREFER_RGB_565` + `.override(80, 80)` + automatic `Glide.pauseRequests()` on `SCROLL_STATE_SETTLING` and `resumeRequests()` on idle.
8. **Smart Auto-Failover Backup Stream & 2.5s Fast Watchdog** (`Models.kt`, `M3uParser.kt`, `XtreamRepository.kt`, `ChannelCacheStore.kt`, `PlayerActivity.kt`):
   - Duplicate normalized channel names with distinct URLs are attached as `backupUrl` on the primary channel and persisted in `ChannelCacheStore`.
   - 2.5s fast stall/error watchdog automatically fails over to `channel.backupUrl` when available.
9. **Persistent Connection Pool, HTTP/2 & Bounded In-Memory DNS Cache** (`NetworkClient.kt`):
   - Bounded 50-entry, 30-minute TTL `quantumDns` cache + 5-minute keep-alive pools (`ConnectionPool(6, 5, TimeUnit.MINUTES)`) + HTTP/2.
10. **Complete DTH Remote Ergonomics, 0.85s Number Zap & Live Telemetry HUD** (`PlayerActivity.kt`):
    - `0.85s` (`850ms`) number auto-tune + instant `OK`/`ENTER` digit tune + `KEYCODE_DEL`/`KEYCODE_LAST_CHANNEL` recall + 3s OSD auto-hide + live FPS/Bitrate/Resolution badge.
11. **Multi-Audio Language Memory & 4-Digit Parental PIN Lock** (`ProfileStore.kt`, `PlayerActivity.kt`):
    - Per-channel saved audio language preference (`audio_lang_<channelId>`) defaulting to Hindi/English (`"hi"`, `"hin"`, `"en"`, `"eng"`).
    - 4-digit Parental PIN lock protecting locked/adult categories.
12. **Global `ComponentCallbacks2` Memory Guard & R8 Full Mode** (`StreamXApp.kt`, `AndroidManifest.xml`, `gradle.properties`, `app/build.gradle.kts`):
    - Global `StreamXApp` + `PlayerActivity` `onTrimMemory` handler + `android.enableR8.fullMode=true`.
